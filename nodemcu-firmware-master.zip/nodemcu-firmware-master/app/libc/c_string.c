#include "c_string.h"

// const char *c_strstr(const char * __s1, const char * __s2){
// }

// char *c_strncat(char * s1, const char * s2, size_t n){
// }

// size_t c_strcspn(const char * s1, const char * s2){
// }

// const char *c_strpbrk(const char * s1, const char * s2){
// }

// int c_strcoll(const char * s1, const char * s2){
// }
